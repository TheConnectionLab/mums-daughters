# Between Us — proof-of-concept prototype

Early-stage, non-clinical educational demonstration of a mother–daughter relationship-skills questionnaire. Created as a technical starting point, **not** as evidence of pilot validation.

## What it does
- Displays 15 illustrative questions across five relational skills dimensions.
- Calculates five domain means (1 to 4).
- Displays a visual profile and selects one predefined learning exercise using a transparent, deterministic rule.
- Uses no external APIs, AI model, blockchain, user authentication, data persistence, or tracking.

## What it does NOT do
- It is **not** a validated questionnaire, a diagnostic tool, or a substitute for safeguarding or mental health support.
- It does **not** provide a fully developed mother-specific assessment; caregiver selection currently uses the sample daughter questions and is labelled accordingly.
- It has **not** been tested with families, verified by developmental psychologists, or subjected to a security/privacy impact assessment.
- It should **not** be used with real children or identifiable family responses in this form.

## Run locally
```bash
pip install -r requirements.txt
streamlit run app.py
```

## Deploy
1. Create a new GitHub repository and upload `app.py`, `logic.py`, `requirements.txt`, `README.md` and `test_logic.py`.
2. Open https://share.streamlit.io/ and select **Create app**.
3. Select the GitHub repository, `main` branch and `app.py` as entrypoint.
4. Deploy and test using fictitious, illustrative responses only.

## Testing
```bash
python -m unittest test_logic.py
```

## Proposed next steps
- Co-design and cognitive-test separate daughter and caregiver wording, with a developmental psychologist.
- Conduct safeguarding and privacy reviews, including jurisdiction-specific compliance and a data-protection impact assessment where required.
- Test usability and comprehension in appropriately consented, supervised pilot settings.
- Add secure hosting, consent flows, role-based access and data-retention policies before collecting any live data.
- Explore constrained AI adaptation only after human review of educational content and risk assessment.

## Transparency
Any use of this repository in a funding application should clearly state that it is an **early proof of concept**, not evidence of existing user trials or validated effectiveness.
